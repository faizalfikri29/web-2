
<div
    class="z-10 fixed inset-0 bg-black/10 hidden [[data-show-stashed-sidebar]_&]:block lg:[[data-show-stashed-sidebar]_&]:hidden"
    x-data x-on:click="document.body.removeAttribute('data-show-stashed-sidebar')"
></div>
<?php /**PATH C:\xampp\htdocs\web-2\praktikum10\room-booking\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/backdrop.blade.php ENDPATH**/ ?>